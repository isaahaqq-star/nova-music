# NOVA MUSIC — 401K Public Player

Static Cloudflare Pages package for YolaJo — 401K.

## Cloudflare Pages settings
- Connect the `nova-music` GitHub repository.
- Framework preset: None.
- Build command: leave blank.
- Build output directory: `/` (repository root).
- Deploy.

The 12 MP3 files are public listening copies. Do not add private WAV masters, API keys, tokens, or service-role credentials to this repository.

401K remains draft/private for distribution purposes. Publishing this showcase is not DSP-distribution authorization.
